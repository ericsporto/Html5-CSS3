x = 0

while(x < 1):
  numero = int(input("Digite um número: "))

  print(numero)

  if numero == 0:
    print("Saindo do loop!")
    break