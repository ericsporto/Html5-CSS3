print("Antes do loop")

numero = 0

while numero < 5:
  print(numero)
  if numero == 3:
    print("O NUMERO É 3!")
  numero = numero + 1

print("Depois do loop")