fim = int(input("Quando o loop vai terminar? "))

inicio = 0

while inicio <= fim:
  print(inicio)
  inicio = inicio + 1