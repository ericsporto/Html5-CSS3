numero = 0

while numero < 10:
  print(numero)

  if numero == 5:
    break

  numero = numero + 1

print("Após o loop")