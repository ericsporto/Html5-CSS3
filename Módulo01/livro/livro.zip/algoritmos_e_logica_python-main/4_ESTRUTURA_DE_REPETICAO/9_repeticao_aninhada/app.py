i = 0

while i < 10:
  print("I: %d" % i)

  x = 0

  while x < 5:

    print("X: %d" % x)
    x = x + 1

  i = i + 1