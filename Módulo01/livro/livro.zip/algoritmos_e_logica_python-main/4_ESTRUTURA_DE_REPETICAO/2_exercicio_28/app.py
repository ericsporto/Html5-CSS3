x = 10

while x <= 50:
  print(x)
  x = x + 1