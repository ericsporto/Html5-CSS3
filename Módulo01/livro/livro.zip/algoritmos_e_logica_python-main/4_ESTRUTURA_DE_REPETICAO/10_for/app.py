palavra = "Testando"

for letra in palavra:
  print(letra)

nome = "Matheus"

for x in nome:
  print(x)
  if x == "M":
    print("Primeira letra do nome")
