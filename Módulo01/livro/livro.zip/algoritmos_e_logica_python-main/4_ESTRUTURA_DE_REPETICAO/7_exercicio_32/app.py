n = 20

while n >= 0:
  print(n)

  if n == 5:
    break

  n = n - 1

print("Pós loop")