numero = 1

while numero <= 50:
  if numero % 2 == 0:
    print(numero)
  numero = numero + 1