livros = {
  "Eragon": 400,
  "Senhor dos Anéis": 360,
  "Narnia": 600
}

for livro in livros:
  print("O livro %s tem %d páginas" % (livro, livros[livro]))