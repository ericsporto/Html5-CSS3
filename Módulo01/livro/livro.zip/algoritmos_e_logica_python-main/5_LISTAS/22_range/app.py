for x in range(9):
  print(x)
  if x == 5:
    print("Aconteceu alguma coisa!")