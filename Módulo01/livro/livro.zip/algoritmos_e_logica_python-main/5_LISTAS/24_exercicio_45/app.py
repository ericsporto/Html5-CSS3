for i in range(3, 100, 3):
  print(i)