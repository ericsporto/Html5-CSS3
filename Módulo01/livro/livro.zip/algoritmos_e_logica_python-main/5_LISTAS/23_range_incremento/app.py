for x in range(5, 26, 5):
  print(x)