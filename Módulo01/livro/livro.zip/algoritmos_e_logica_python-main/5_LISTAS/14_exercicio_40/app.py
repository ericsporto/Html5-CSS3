l = []

i = 0

while i < 5:
  el = input("Digite um elemento da lista: ")
  l.append(el)
  i = i + 1

print(l)