lista = ["Matheus", "João", "Pedro"]

nova_lista = lista[:]

print(lista)
print(nova_lista)

nova_lista[0] = "Maguila"

print(nova_lista)
print(lista)