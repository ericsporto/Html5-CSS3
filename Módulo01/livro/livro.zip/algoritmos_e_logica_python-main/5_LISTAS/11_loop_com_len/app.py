lista = [1,2,3,4,5,6,7,98,12,23,32,3,43,43,34,43,]

i = 0

while i < len(lista):
  print(lista[i])
  i = i + 1