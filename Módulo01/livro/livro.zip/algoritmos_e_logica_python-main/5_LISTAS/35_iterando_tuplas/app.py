tupla = ("Matheus", "João", "Pedro")

for nome in tupla:
  print(nome)

  if nome == "João":
    print("Parabéns João!")

i = 0

while i < len(tupla):
  print(tupla[i])
  i = i + 1