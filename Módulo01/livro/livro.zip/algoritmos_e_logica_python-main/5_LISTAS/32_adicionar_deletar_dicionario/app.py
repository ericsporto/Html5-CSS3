dic = {}

print(dic)

dic["nome"] = "Matheus"

print(dic)

print(dic["nome"])

dic["sobrenome"] = "Battisti"

print(dic)

del dic["nome"]

print(dic)