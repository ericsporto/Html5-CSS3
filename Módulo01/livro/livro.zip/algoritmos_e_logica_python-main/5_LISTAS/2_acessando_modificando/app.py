lista = [1,2,3,4,5]

print(lista[0])

print(lista[3])

nomes = ["João", "Raimundo", "Pedro"]

nomes[1] = "Matheus"

print(nomes)

print("O meu nome é %s" % nomes[1])

nome = nomes[1]

print(nome)