lista = [10, 20, 30, 40]

print(lista)

del lista[0]

print(lista)

del lista[len(lista) - 1]

print(lista)