lista = [1,2,3]

nova_lista = []

nova_lista = lista

print(lista)
print(nova_lista)

nova_lista[0] = 1000

print(nova_lista)

print("LISTA UM:")

print(lista)

lista[0] = 5000

print(nova_lista)