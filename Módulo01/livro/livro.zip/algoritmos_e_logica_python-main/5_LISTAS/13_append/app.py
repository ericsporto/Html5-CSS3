lista = [0,1,2,3,4]

lista.append(5)

print(lista)

nomes = ["Matheus", "João"]

nomes.append("Pedro")

print(nomes)

if nomes[2] != "Maria":
  nomes.append("Maria")

print(nomes)