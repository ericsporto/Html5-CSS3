carro = {
  "portas": 4,
  "janelas": 4,
  "motor": 2.0,
  "teto_solar": True,
  "cambio": "Automático"
}

print(carro)

print(carro['portas'])

print(carro['cambio'])