lista = [1, 2, 3, 4]

print(len(lista))

if(len(lista) == 3):
  print("A lista tem 3 elementos!")
else:
  print("A lista é maior do que o esperado!")