lista = []

print(lista)
print(type(lista))

numeros = [1, 2, 3, 4, 5]

print(numeros)

nomes = ["João", "Matheus", "Pedro"]

print(nomes)

booleans = [True, False, True]

print(booleans)