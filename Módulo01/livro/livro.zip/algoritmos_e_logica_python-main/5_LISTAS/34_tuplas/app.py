tupla = (1, 2, 3)

print(tupla)

print(type(tupla))

print(tupla[0])