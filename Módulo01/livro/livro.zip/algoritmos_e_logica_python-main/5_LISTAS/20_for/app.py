lista = [1,2,3,4,5]

print(lista)

for n in lista:
  print(n)

i = 0

while i < len(lista):
  print(lista[i])
  i = i + 1