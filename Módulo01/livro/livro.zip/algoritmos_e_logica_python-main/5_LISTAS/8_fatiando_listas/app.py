lista = [5,4,1,2,3,50,10,20]

lista_nova = lista[2:5]

print(lista_nova)

lista_n = lista[2:]

print(lista_n)

l = lista[:4]

print(l)