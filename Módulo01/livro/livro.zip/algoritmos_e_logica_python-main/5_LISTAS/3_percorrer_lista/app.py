lista = ["Maçã", "Uva", "Mamão", "Goiaba"]

i = 0

while i < 4:
  print(lista[i])
  i = i + 1 