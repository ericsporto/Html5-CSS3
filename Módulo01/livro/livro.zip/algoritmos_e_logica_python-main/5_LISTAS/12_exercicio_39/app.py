lista = [5,10,15,20,25]

print(lista)

i = 0

while i < len(lista):
  print(lista[i] + 10)
  i = i + 1 