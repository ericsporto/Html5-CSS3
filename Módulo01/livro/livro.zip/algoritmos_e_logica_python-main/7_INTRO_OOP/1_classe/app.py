class Pessoa:
  def __init__(self, nome, idade, sobrenome):
    self.nome = nome
    self.idade = idade
    self.sobrenome = sobrenome