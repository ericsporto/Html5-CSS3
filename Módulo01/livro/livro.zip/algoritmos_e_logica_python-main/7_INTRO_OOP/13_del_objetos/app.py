class Person:
  pass

matheus = Person()
joao = Person()

print(matheus)
print(joao)

del matheus

print(joao)