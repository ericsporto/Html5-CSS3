saldo = 359.56

deposito = float(input("Quanto deseja depositar? "))

print(saldo)
print(deposito)

saldo = saldo + deposito

print(saldo)

fatura_cartao = 125.98

saldo = saldo - fatura_cartao

print(saldo)

print("O saldo restante na conta é de R$%.2f" % saldo)