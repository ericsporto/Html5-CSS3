nome = "Matheus"

print("Olá " + nome)

velocidade = "100"
carro = "BMW"
cidade = "São Paulo"

print("O veículo " + carro + " estava a " + velocidade + "km/h em " + cidade)

saudacao = "Olá"

print(saudacao + " " + nome)

sobrenome = "Battisti"
espacador = " "

print(nome + espacador + sobrenome)