numero = 100

print(numero)

print(type(numero))

n = 12.59

print(n)

print(type(n))