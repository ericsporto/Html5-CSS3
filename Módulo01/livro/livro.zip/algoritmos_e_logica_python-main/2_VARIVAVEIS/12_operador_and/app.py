a = 5
b = 10
c = 2
d = 8

print(a > b and c > d)
print(a > b and c < d)
print(c < d and b < c)

print(a < b and b > c)