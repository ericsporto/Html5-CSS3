salario = 1800
aumento = 400

novo_salario = salario + aumento

print(novo_salario)