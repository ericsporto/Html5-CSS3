palavra = "Matheus"

print(palavra[:4])

print(palavra[2:])

print(palavra[:])

print(palavra[0:-2])

print(palavra[0:-6])