nome = input("Digite o seu nome: ")

print(nome)

print("Olá %s, tudo bem?" % nome)