verdadeiro = True
falso = False

print(not verdadeiro)
print(not falso)

print(not(5 > 2))
print(not(5 < 2))