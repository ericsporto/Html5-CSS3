numero_texto = input("Digite um número: ")

print(numero_texto)

numero = int(numero_texto)

novo_numero = 5 + numero

print(novo_numero)

novo_numero = int(input("Digite mais um número: "))

print(numero + novo_numero)

novo_float = float(input("Digite o que você tem de dinheiro na carteira: "))

print(novo_float)

soma_float = 100.48 + novo_float

print(soma_float)