a = 5
b = 10

print(a > b or b == 11)

print(b > a or b == 10)
print(a > b or b == 10)
print(b > a or b == 20)

nome = "Matheus"
idade = 29

print(nome == "João" or idade > 20)
