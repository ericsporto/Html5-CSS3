a = 15
b = 10
c = 15

print(a >= b)
print(a >= c)
print(a > c)

print(a <= b)
print(a <= c)
print(a < c)