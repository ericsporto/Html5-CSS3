velocidade_a = 90
velocidade_b = 80
velocidade_c = 60

limite = 80

print(velocidade_a >= limite)
print(velocidade_b >= limite)
print(velocidade_c >= limite)