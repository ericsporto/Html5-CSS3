idade = input("Qual a sua idade? ")

print(idade)

print("Você tem " + idade + " anos")