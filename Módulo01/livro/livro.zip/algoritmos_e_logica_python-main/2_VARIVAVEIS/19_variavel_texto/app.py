profissao = "Programador"

print(profissao)
print("Programador")

frase = "O rato roeu a roupa do rei de Roma"

print(len(profissao))
print(len("Programador"))

print(len(frase))