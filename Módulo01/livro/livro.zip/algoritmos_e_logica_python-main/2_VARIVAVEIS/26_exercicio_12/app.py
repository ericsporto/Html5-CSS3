poupanca = 25490.54
juros = 125.32
cartao_credito = 2009.22

print("Você tem depositado na sua poupança R$%.2f e seu rendimento do último mês foi R$%.2f. E a fatura do seu cartão de crédito foi de R$%.2f" % (poupanca, juros, cartao_credito))