idade = 18
carteiraMotorista = True

print(idade >= 18 and carteiraMotorista == True)

print("Pode dirigir")

velocidade = 90
radar = 100
radarFuncionando = False

print(velocidade > radar and radarFuncionando == True)

print("Não foi multado!")