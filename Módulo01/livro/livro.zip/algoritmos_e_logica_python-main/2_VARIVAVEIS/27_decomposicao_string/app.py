teste = "Palavra"

print(teste[0:2])

frase = "Hoje está fazendo sol aqui em Floripa"

print(frase[18:21])

sol = frase[18:21]

print(sol)

print("Temos um dia de %s hoje" % sol)