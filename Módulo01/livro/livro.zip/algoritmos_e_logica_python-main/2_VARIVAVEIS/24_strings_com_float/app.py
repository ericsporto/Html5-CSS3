pi = 3.1439247237842873478

print("O valor de pi é %.2f" % pi)

motor = 2.0

print("O motor do meu carro é %.1f" % motor)