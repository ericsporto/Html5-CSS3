ano2020 = 2020

print(ano2020)

_2020ano = 2020

print(_2020ano)

testando_espaco = "teste"

print(testando_espaco)

nome_completo = "Matheus Battisti"

print(nome_completo)