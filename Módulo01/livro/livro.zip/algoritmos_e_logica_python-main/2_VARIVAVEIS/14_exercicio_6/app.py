x = True
y = False
z = False

print(x and y)
print(not x)
print(x and x)
print(y and y)
print(y or x)
print(y and z)
print(not y)
print(x and z)

print(5 > 2 and z == False)