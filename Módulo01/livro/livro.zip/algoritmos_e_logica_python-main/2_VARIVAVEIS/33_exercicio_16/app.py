num_a = int(input("Digite o primeiro número: "))
num_b = int(input("Digite o segundo número: "))

soma = num_a + num_b

print("A soma dos dois números é %d" % soma)