frase = "Nós estamos procurando o rubi na floresta"

rubi = frase[25:29]

print(rubi)