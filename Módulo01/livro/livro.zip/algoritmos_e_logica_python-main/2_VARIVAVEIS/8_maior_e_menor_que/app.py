a = 10
b = 5
c = 20

print(a > b)
print(a > c)

print(a < b)
print(a < c)