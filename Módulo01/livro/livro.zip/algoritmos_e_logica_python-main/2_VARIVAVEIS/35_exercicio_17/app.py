base = int(input("Digite a base: "))
expoente = int(input("Digite a expoente: "))

calculo = base ** expoente

print("O resultado da potência é %d" % calculo)