a = 10
b = 10
c = 15

print(a == b)
print(b == c)

d = 10
e = 5
f = 10

print(d != e)
print(d != f)

idade = 18
censura = 18

print(idade == censura)