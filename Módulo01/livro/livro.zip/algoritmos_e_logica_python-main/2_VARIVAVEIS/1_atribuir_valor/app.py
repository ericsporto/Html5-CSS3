nome = "Matheus"

tipo_var = type(nome)

print(nome)

print(tipo_var)

idade = 29

print(idade)

print(type(idade))