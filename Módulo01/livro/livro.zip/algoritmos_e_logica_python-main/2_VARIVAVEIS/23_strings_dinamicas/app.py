name = "Rogério"

print("Olá, meu nome é %s" % name)

idade = 29

print("Eu tenho %d anos" % idade)

carro = "Ferrari"
ano = 2000

print("O meu carro é uma %s e foi fabricado no ano %d" % (carro, ano))
