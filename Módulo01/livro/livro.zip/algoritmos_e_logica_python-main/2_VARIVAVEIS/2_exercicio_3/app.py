frase = "O rato roeu a roupa do rei de Roma"

print(frase)

print(type(frase))