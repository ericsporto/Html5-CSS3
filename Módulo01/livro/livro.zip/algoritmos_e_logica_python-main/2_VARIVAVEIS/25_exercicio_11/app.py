nome = "Matheus"
idade = 29

print("Eu sou o %s e tenho %d anos" % (nome, idade)) 

poupanca = 1245.85

print("Eu tenho um total de R$%.2f na poupança." % poupanca)