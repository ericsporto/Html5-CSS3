a = 5
b = 3
c = 10
d = 2

print(a > b)
print(c == a)
print(d != a)
print(a <= c)
print(b > c)
print(a != c)
print(d >= a)
print(d != b)
print(d < c)
print(b >= a)