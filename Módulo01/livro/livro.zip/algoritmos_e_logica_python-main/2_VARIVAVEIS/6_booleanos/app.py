verdadeiro = True

print(verdadeiro)
print(type(verdadeiro))

falso = False

print(falso)
print(type(falso))