numero = int(input("Digite um número:"))

print("Continuando")

flutuante = float(input("Digite seu salario: "))