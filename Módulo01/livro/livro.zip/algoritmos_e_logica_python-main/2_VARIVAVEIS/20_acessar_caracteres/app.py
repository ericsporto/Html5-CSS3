palavra = "Caminhão"

print(palavra[0])

print(palavra[5])

frase = "Estou dirigindo um caminhão na BR 101"

print(frase[20])

print(frase[35])

print(len(frase))