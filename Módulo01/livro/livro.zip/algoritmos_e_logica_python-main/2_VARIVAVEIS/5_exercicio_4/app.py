x = 100
y = 50.50

z = x + y

print(z)