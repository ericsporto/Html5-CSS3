media = 7

nota_a = 8
nota_b = 4
nota_c = 7

print(nota_a >= media)
print(nota_b >= media)
print(nota_c >= media)

prova_a = 5
prova_b = 8
prova_c = 10

media_provas = (prova_a + prova_b + prova_c) / 3

print(media_provas)

print(media_provas >= media)