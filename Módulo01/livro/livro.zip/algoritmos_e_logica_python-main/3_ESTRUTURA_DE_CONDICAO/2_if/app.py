if 10 > 5:
  verdura = "Cenoura"
  print("Entrou no if!")
  print(verdura)

print("ANTES DO IF")

if 5 > 10:
  print("IF FALSO")
  
print("DEPOIS DO IF")

nome = "Matheus"
idade = 28

if nome == "Matheus" and idade == 29:
  print("Olá Matheus")