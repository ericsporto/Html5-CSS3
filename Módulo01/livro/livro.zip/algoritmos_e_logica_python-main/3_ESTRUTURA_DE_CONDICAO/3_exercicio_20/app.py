idade = int(input("Digite a sua idade: "))

print(idade)

if idade >= 18:
  print("Pode entrar na balada!")