salario = float(input("Qual é o seu salário? "))

if salario > 1800:
  print("Você precisa pagar imposto de renda")
else:
  print("Você NÃO precisa pagar imposto de renda")