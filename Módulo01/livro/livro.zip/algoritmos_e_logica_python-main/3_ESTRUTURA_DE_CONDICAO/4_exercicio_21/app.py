numero_de_rodas = int(input("Quantas rodas tem o veículo? "))

print(numero_de_rodas)

if(numero_de_rodas > 2):
  print("O seu veículo precisa pagar pedágio.")

if(numero_de_rodas == 2):
  print("Você pode seguir adiante.")