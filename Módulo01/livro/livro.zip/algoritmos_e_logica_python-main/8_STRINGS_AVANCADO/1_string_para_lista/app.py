palavra = "Testando"

print(list(palavra))

print(palavra[0])

lista = ["O", "rato", "roeu", "a", "roupa"]

print(" ".join(lista))