frase = "Esta é a frase que vamos checar as ocorrências da palavra frase"

print(frase.count("frase"))

if frase.count("frase") == 2:
  print("A contagem está correta!")

print(frase.count("Olá"))

contador = frase.count("frase")

print(contador)