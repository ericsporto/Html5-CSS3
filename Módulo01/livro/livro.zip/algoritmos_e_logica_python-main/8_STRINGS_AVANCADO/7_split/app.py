itens = "Maçaneta, Porta, Motor, Teto Solar, Janela, Embreagem"

lista = itens.split(", ")

print(lista)


teste = "Item1@Item2@Item3"

print(teste.split("@"))