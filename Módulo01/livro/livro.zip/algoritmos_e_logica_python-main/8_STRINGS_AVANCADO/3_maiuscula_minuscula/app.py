palavra = "Matheus"

print(palavra.lower())

teste = "UMA FRASE EM CAPS"

print(teste.lower())

min = "tUdO Em mInúScUlo"

print(min.upper())

min2 = min.upper()

print(min2)