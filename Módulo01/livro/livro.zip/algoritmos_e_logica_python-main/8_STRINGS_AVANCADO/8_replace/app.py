frase = "O rato roeu a roupa do rei de Roma"

print(frase.replace("rato", "leão"))

frase2 = "Vou testar o replace em duas palavras testar testar"

print(frase2.replace("testar", "trocou", 2))