frase = "Testamos o começo da string"

print(frase.startswith("Testamos"))

print(frase.startswith("string"))

if(frase.startswith("Testamos") == True):
  print("Encontramos a palavra!")

print(frase.endswith("string"))

print(frase.endswith("Testamos"))