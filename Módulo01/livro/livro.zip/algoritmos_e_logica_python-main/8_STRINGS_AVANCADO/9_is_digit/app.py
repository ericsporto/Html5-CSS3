numero = "12345"

print(numero.isdigit())

frase = "asd"

print(frase.isdigit())

numero2 = "123.5"

print(numero2.replace(".", "").isdigit())