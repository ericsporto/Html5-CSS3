def soma_numeros(a, b = 5, c = 10):
  print(a + b + c)


soma_numeros(1, 2, 3)

soma_numeros(10, 20)

soma_numeros(10, 50)

soma_numeros(10)