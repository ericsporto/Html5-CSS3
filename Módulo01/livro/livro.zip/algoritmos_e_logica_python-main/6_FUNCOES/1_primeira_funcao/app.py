def digaOi(nome):
  print("Olá %s!" % nome)

digaOi("Matheus")

digaOi("Pedro")

if 10 > 5:
  digaOi("João")

digaOi("José")

def digaOla():
  print("Olá Mundo!")
  print("Olá Matheus")

digaOla()