def imprimeNome(nome = "Matheus"):
  print("Olá %s" % nome)

imprimeNome()

imprimeNome("João")

imprimeNome("Marcos")