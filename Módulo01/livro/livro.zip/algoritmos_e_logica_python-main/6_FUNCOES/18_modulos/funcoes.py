def ola_modulo():
  print("Olá do seu módulo!")

def ola_nome(nome):
  print("Olá %s" % nome)