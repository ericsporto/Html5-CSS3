import funcoes
import cart

funcoes.ola_modulo()

funcoes.ola_nome("Matheus")

produto = ["Camisa", 15.99]

cart.apresentar_item(produto)