def apresentar_item(item):
  print("O produto é %s e o seu preço é R$%.2f" % (item[0], item[1]))