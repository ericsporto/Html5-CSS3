import random

print(random.randint(1, 10))

aleatorio = random.randint(1, 1000)

print(aleatorio)