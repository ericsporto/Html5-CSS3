soma = lambda x: x + 10

print(soma(50))

soma_dois_numeros = lambda a, b: a + b

print(soma_dois_numeros(5, 2))
