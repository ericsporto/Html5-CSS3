def multiplicacao(a, b):
  print(a * b)

multiplicacao(2, 4)

num_a = 10
num_b = 20

multiplicacao(num_a, num_b)

multiplicacao(num_b, num_b)

multiplicacao(num_a, 15)