import matematica

soma = matematica.soma(5, 5)

print(soma)

mult = matematica.multiplicacao(2, 22)

print(mult)