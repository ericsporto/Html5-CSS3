def soma(a, b):
  return a + b

def multiplicacao(a, b):
  return a * b